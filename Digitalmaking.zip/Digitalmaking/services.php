<?php
 include("include/otherheader.php");
?>

	<!-- Start main-content -->
	<section class="page-title" style="background-image: url(images/background/page-title.jpg);">
		<div class="auto-container">
			<div class="title-outer">
				<h1 class="title"> Our Services</h1>
			
			</div>
		</div>
	</section>
	<!-- end main-content -->
	
	<!-- Services Section Four -->
	<section class="services-section-four bg-silver-light">
		<div class="auto-container">

			<div class="row">
				<!-- Service Block Four -->
				<div class="service-block-four col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="services.php"><img src="images/resource/service2-1.jpg" alt=""></a></figure>
						</div>
						<div class="content-box">
							<i class=' icon bx bxl-dev-to'></i>
							<h5 class="title"><a href="services.php">Website <br>Development</a></h5>
							<div class="text">Many agencies specialize in website development. 
								They often have a team of designers, developers, and other professionals.</div>
						</div>
					</div>
				</div>
				
				<!-- Service Block Four -->
				<div class="service-block-four col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="services.php"><img src="images/resource/service2-2.jpg" alt=""></a></figure>
						</div>
						<div class="content-box">
							<i class=' icon bx bx-desktop'></i>
							<h5 class="title"><a href="services.php">Graphic <br>Designing</a></h5>
							<div class="text">We are providing a wide range of graphics designing services including logo designing, 
								poster designing, banner designing.</div>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block-four col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="services.php"><img src="images/resource/service2-3.jpg" alt=""></a></figure>
						</div>
						<div class="content-box">
							<i class=' icon bx bxs-videos'></i>
							<h5 class="title"><a href="services.php">Video <br>Editing</a></h5>
							<div class="text">In the fast-paced digital era, where content is king, the demand for high-quality 
								videos has never been higher.</div>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block-four col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="services.php"><img src="images/resource/service2-4.jpg" alt=""></a></figure>
						</div>
						<div class="content-box">
							<i class='icon bx bx-globe'></i>
							<h5 class="title"><a href="services.php">Digital <br>Marketing</a></h5>
							<div class="text">Digital Making is a Digital Marketing Agency provides complete digital 
								marketing solutions for SME’s and Individuals.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--End services-section Two-->

	<!-- Main Footer -->
	<footer class="main-footer">
		<div class="bg bg-pattern-6"></div>
		<!-- Footer Uppper -->
		<div class="footer-upper">
			<div class="auto-container">
				<div class="row">
					<!-- Contact info Block -->
					<div class="contact-info-block col-lg-4 col-md-6">
						<div class="inner">
							<i class='icon bx bx-map' ></i>
							<div class="text">Office No - 202, 2nd Floor, <br>F/F, Main
								Rd,West Guru <br>Angad Nagar, Nirman Vihar, <br>Laxmi Nagar, New Delhi, <br> Delhi 
								110092</div>
						</div>
					</div>
					<!-- Contact info Block -->
					<div class="contact-info-block col-lg-4 col-md-6">
						<div class="inner">
							<i class='icon bx bx-envelope' ></i>
							<div class="text">
								<a href="mailto:digitalmaking97@gmail.com">Digitalmaking97@gmail.com</a>
								<a href="tel:+91 9708766254/9801307801">+91 9708766254/9801307801</a>
							</div>
						</div>
					</div>
					<!-- Contact info Block -->
					<div class="contact-info-block col-lg-4 col-md-6">
						<div class="inner">
							<i class='icon bx bx-time' ></i>
							<div class="text">Mon - Sat: 8:00 am to 6:00 pm <br>Sunday: CLOSED</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php
		include("include/footer.php");
		?>